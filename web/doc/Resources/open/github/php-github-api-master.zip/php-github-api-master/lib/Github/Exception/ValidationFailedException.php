<?php

namespace Github\Exception;

/**
 * ValidationFailedException
 *
 * @author Joseph Bielawski <stloyd@gmail.com>
 */
class ValidationFailedException extends ErrorException
{

}
