<?php

namespace Github\Exception;

interface ExceptionInterface
{

}
