## Organization / Teams API
[Back to the "Organization API"](../organization.md) | [Back to the navigation](../index.md)

Wraps [GitHub Organization Teams API](http://developer.github.com/v3/organization/teams/).

To be written...
