## Organization API
[Back to the navigation](index.md)

Wraps [GitHub Organization API](http://developer.github.com/v3/organization/).

Additional APIs:
* [Members API](organization/members.md)
* [Teams API](organization/teams.md)

To be written...
