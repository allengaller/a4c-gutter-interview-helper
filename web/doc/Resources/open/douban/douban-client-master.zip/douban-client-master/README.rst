douban-client
=============

Python client library for Douban APIs (OAuth 2.0)