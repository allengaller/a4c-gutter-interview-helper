# -*- coding: utf-8 -*-

from framework import DoubanClientTestBase, DoubanAPIError, main

class TestApiError(DoubanClientTestBase):
    pass


if __name__ == '__main__':
    main()
