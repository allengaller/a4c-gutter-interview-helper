<?php
/* PHP SDK
 * @version 2.0.0
 * @author connect@qq.com
 * @copyright © 2013, Tencent Corporation. All rights reserved.
 */

define("ROOT",dirname(dirname(__FILE__))."/");
define("CLASS_PATH",ROOT."class/");
